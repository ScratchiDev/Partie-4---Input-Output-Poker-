import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class MainPoker implements Comparable<MainPoker> {
    private String[] cartes;
    private static final Map<Character, Integer> VALEURS;
    private static final char[] VALEURS_CARTES = {'2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A'};
    private static final String[] SYMBOLES_COULEUR = {"♠", "♥", "♦", "♣"};
    private static final String[][] ASCII_CARTES = new String[VALEURS_CARTES.length * SYMBOLES_COULEUR.length][7];

    static {
        Map<Character, Integer> valeurs = new HashMap<>();
        valeurs.put('2', 2);
        valeurs.put('3', 3);
        valeurs.put('4', 4);
        valeurs.put('5', 5);
        valeurs.put('6', 6);
        valeurs.put('7', 7);
        valeurs.put('8', 8);
        valeurs.put('9', 9);
        valeurs.put('T', 10);
        valeurs.put('J', 11);
        valeurs.put('Q', 12);
        valeurs.put('K', 13);
        valeurs.put('A', 14);
        VALEURS = Collections.unmodifiableMap(valeurs);

        for (int i = 0; i < VALEURS_CARTES.length; i++) {
            for (int j = 0; j < SYMBOLES_COULEUR.length; j++) {
                ASCII_CARTES[i * SYMBOLES_COULEUR.length + j][0] = "┌───────────┐";
                ASCII_CARTES[i * SYMBOLES_COULEUR.length + j][1] = "│ " + VALEURS_CARTES[i] + "         │";
                ASCII_CARTES[i * SYMBOLES_COULEUR.length + j][2] = "│           │";
                ASCII_CARTES[i * SYMBOLES_COULEUR.length + j][3] = "│     " + SYMBOLES_COULEUR[j] + "     │";
                ASCII_CARTES[i * SYMBOLES_COULEUR.length + j][4] = "│           │";
                ASCII_CARTES[i * SYMBOLES_COULEUR.length + j][5] = "│         " + VALEURS_CARTES[i] + " │";
                ASCII_CARTES[i * SYMBOLES_COULEUR.length + j][6] = "└───────────┘";
            }
        }
    }

    public MainPoker(String[] main) {
        this.cartes = main;
        Arrays.sort(this.cartes, Comparator.comparingInt(carte -> VALEURS.get(carte.charAt(0))));
    }

    @Override
    public int compareTo(MainPoker autre) {
        int rangCetteMain = evaluerRang(this.cartes);
        int rangAutreMain = evaluerRang(autre.cartes);
        return Integer.compare(rangCetteMain, rangAutreMain);
    }

    private int evaluerRang(String[] cartes) {
        return VALEURS.get(cartes[4].charAt(0));
    }

    public String asciiArt() {
        StringBuilder sb = new StringBuilder();
        for (String carte : cartes) {
            if (carte.length() > 0) {
                int indexValeurCarte = getIndexValeurCarte(carte.charAt(0));
                int indexCouleurCarte = getIndexCouleurCarte(carte.charAt(1));
                if (indexValeurCarte != -1 && indexCouleurCarte != -1) {
                    String[] asciiCarte = ASCII_CARTES[indexValeurCarte * SYMBOLES_COULEUR.length + indexCouleurCarte];
                    for (String ligne : asciiCarte) {
                        sb.append(ligne).append("\n");
                    }
                } else {
                    System.out.println("Carte invalide : " + carte);
                }
            }
        }
        return sb.toString();
    }

    private int getIndexValeurCarte(char valeur) {
        for (int i = 0; i < VALEURS_CARTES.length; i++) {
            if (VALEURS_CARTES[i] == valeur) {
                return i;
            }
        }
        return -1;
    }

    private int getIndexCouleurCarte(char couleur) {
        String couleurStr = String.valueOf(couleur);
        for (int i = 0; i < SYMBOLES_COULEUR.length; i++) {
            if (SYMBOLES_COULEUR[i].equals(couleurStr)) {
                return i;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("src/input.txt"));
            BufferedWriter bw = new BufferedWriter(new FileWriter("src/output.txt"));

            String line;
            while ((line = br.readLine()) != null) {
                String[] mainCartes = line.split(" ");
                MainPoker main = new MainPoker(mainCartes);
                bw.write(main.asciiArt());
                bw.newLine();
            }

            br.close();
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
